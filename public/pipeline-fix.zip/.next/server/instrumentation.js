var R=require("./chunks/[turbopack]_runtime.js")("server/instrumentation.js")
R.c("server/chunks/[root-of-the-server]__f972409f._.js")
R.m(23322)
module.exports=R.m(23322).exports
