1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/2f236954d6a65e12.js"],"default"]
3:I[37457,["/_next/static/chunks/2f236954d6a65e12.js"],"default"]
0:{"buildId":"L-fAWMVu1hGcPqAQXNYw3","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":null,"isPartial":false}
