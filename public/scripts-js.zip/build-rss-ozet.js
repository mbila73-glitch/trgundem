var __create = Object.create;
var __getProtoOf = Object.getPrototypeOf;
var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
function __accessProp(key) {
  return this[key];
}
var __toESMCache_node;
var __toESMCache_esm;
var __toESM = (mod, isNodeMode, target) => {
  var canCache = mod != null && typeof mod === "object";
  if (canCache) {
    var cache = isNodeMode ? __toESMCache_node ??= new WeakMap : __toESMCache_esm ??= new WeakMap;
    var cached = cache.get(mod);
    if (cached)
      return cached;
  }
  target = mod != null ? __create(__getProtoOf(mod)) : {};
  const to = isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target;
  for (let key of __getOwnPropNames(mod))
    if (!__hasOwnProp.call(to, key))
      __defProp(to, key, {
        get: __accessProp.bind(mod, key),
        enumerable: true
      });
  if (canCache)
    cache.set(mod, to);
  return to;
};

// scripts/build-rss-ozet.ts
var import_db = require("../src/lib/db");
var import_z_ai_web_dev_sdk = __toESM(require("z-ai-web-dev-sdk"));
var import_node_fs = require("node:fs");
var import_node_path = __toESM(require("node:path"));
var import_date_fns = require("date-fns");
var import_locale = require("date-fns/locale");
var OUTPUT_PATH = import_node_path.default.join(process.cwd(), "download", "rss_ozet.md");
var SHINGLE1_THRESHOLD = 0.22;
var SHINGLE2_THRESHOLD = 0.2;
var MAX_SOURCES_PER_GROUP = 5;
var MIN_SUMMARY_WORDS = 150;
var REBUILD_ONLY = process.env.REBUILD_ONLY === "1";
var TURKISH_STOPWORDS = new Set([
  "ve",
  "veya",
  "ile",
  "için",
  "gibi",
  "kadar",
  "sadece",
  "daha",
  "çok",
  "az",
  "bir",
  "iki",
  "üç",
  "dört",
  "beş",
  "altı",
  "yedi",
  "sekiz",
  "dokuz",
  "on",
  "bu",
  "şu",
  "o",
  "ben",
  "sen",
  "biz",
  "siz",
  "onlar",
  "bizler",
  "da",
  "de",
  "ta",
  "te",
  "ki",
  "mi",
  "mı",
  "mu",
  "mü",
  "ne",
  "nasıl",
  "niçin",
  "niye",
  "olan",
  "olarak",
  "göre",
  "sonra",
  "önce",
  "en",
  "her",
  "hiç",
  "ama",
  "fakat",
  "lakin",
  "ancak",
  "şey",
  "yani",
  "ise",
  "ya",
  "veyahut",
  "hem",
  "değil",
  "üzere",
  "rağmen",
  "kez",
  "doğru",
  "tam",
  "üzerine",
  "yerine",
  "diye",
  "beri",
  "böyle",
  "şöyle",
  "neden",
  "hangi",
  "olduğu",
  "oldu",
  "olacak",
  "olmuş",
  "oluyor",
  "bunlar",
  "şunlar"
]);
var CATEGORY_LIMITS = {
  "Güncel": 10,
  "Kamu / Resmi": 7,
  "Ekonomi / Finans": 7,
  "Spor / Magazin": 5,
  "Bilim / Teknoloji": 3,
  "Kültür / Sanat": 3
};
var CATEGORY_ORDER = Object.keys(CATEGORY_LIMITS);
var TR_MONTHS = [
  "Oca",
  "Şub",
  "Mar",
  "Nis",
  "May",
  "Haz",
  "Tem",
  "Ağu",
  "Eyl",
  "Eki",
  "Kas",
  "Ara"
];
var zaiPromise = null;
async function getZAI() {
  if (!zaiPromise)
    zaiPromise = import_z_ai_web_dev_sdk.default.create();
  return zaiPromise;
}
function normalize(text) {
  if (!text)
    return "";
  let t = text.toLowerCase().replace(/İ/g, "i").replace(/I/g, "ı").replace(/[^\w\sçğıöşüâîû]/g, " ").replace(/\s+/g, " ").trim();
  const words = t.split(" ").filter((w) => w && !TURKISH_STOPWORDS.has(w) && w.length > 2);
  return words.join(" ");
}
function shingles(text, n) {
  const words = text.split(" ").filter(Boolean);
  if (words.length < n)
    return new Set([words.join(" ")]);
  const out = new Set;
  for (let i = 0;i <= words.length - n; i += 1) {
    out.add(words.slice(i, i + n).join(" "));
  }
  return out;
}
function jaccard(a, b) {
  if (!a.size || !b.size)
    return 0;
  let inter = 0;
  for (const x of a)
    if (b.has(x))
      inter += 1;
  const union = a.size + b.size - inter;
  return union === 0 ? 0 : inter / union;
}
function isSimilar(sh1A, sh2A, sh1B, sh2B) {
  if (jaccard(sh2A, sh2B) >= SHINGLE2_THRESHOLD)
    return true;
  if (jaccard(sh1A, sh1B) >= SHINGLE1_THRESHOLD)
    return true;
  return false;
}

class UnionFind {
  parent;
  rank;
  constructor(n) {
    this.parent = Array.from({ length: n }, (_, i) => i);
    this.rank = new Array(n).fill(0);
  }
  find(x) {
    while (this.parent[x] !== x) {
      this.parent[x] = this.parent[this.parent[x]];
      x = this.parent[x];
    }
    return x;
  }
  union(a, b) {
    const ra = this.find(a), rb = this.find(b);
    if (ra === rb)
      return;
    if (this.rank[ra] < this.rank[rb]) {
      this.parent[ra] = rb;
    } else {
      this.parent[rb] = ra;
      if (this.rank[ra] === this.rank[rb])
        this.rank[ra] += 1;
    }
  }
}
function fmtDate(d) {
  if (!d)
    return "";
  const date = typeof d === "string" ? new Date(d) : d;
  if (Number.isNaN(date.getTime()))
    return "";
  return `${date.getDate()} ${TR_MONTHS[date.getMonth()]} ${date.getFullYear()} ${String(date.getHours()).padStart(2, "0")}:${String(date.getMinutes()).padStart(2, "0")}`;
}
function pickImage(sources, excludeUrls) {
  const counts = new Map;
  for (const s of sources) {
    if (!s.imageUrl)
      continue;
    if (excludeUrls && excludeUrls.has(s.imageUrl))
      continue;
    counts.set(s.imageUrl, (counts.get(s.imageUrl) ?? 0) + 1);
  }
  let common = null;
  let commonCount = 0;
  for (const [url, c] of counts) {
    if (c > commonCount) {
      common = url;
      commonCount = c;
    }
  }
  if (common && commonCount >= 2)
    return common;
  const sorted = [...sources].sort((a, b) => b.publishedAt.getTime() - a.publishedAt.getTime());
  for (const s of sorted) {
    if (s.imageUrl && (!excludeUrls || !excludeUrls.has(s.imageUrl)))
      return s.imageUrl;
  }
  return null;
}
function buildUserPrompt(articleSources) {
  const blocks = articleSources.map((a, i) => {
    const parts = [
      `[Kaynak ${i + 1}: ${a.source.name}]`,
      `Başlık: ${a.title}`,
      a.description ? `Açıklama: ${a.description.slice(0, 800)}` : "",
      a.content ? `İçerik: ${a.content.slice(0, 4000)}` : ""
    ].filter(Boolean);
    return parts.join(`
`);
  });
  return `Aşağıda aynı haberi farklı kaynaklardan alınmış ${articleSources.length} ayrı RSS metni var. Bunları okuyarak:

1. Haberin başlığını ~6-10 kelimelik Türkçe bir başlık olarak YENİ yaz (kaynak başlıklarını birebir kopyalama).
2. Haberin özetini EN AZ 150, EN FAZLA 300 KELİME olarak kendi cümlelerinle yaz.
3. Haberin kategorisini aşağıdaki 6 kategoriden biriyle belirle:
   - "Güncel" (genel haberler, siyaset, toplum)
   - "Kamu / Resmi" (devlet, kurum, resmi açıklamalar, memur, atama)
   - "Ekonomi / Finans" (ekonomi, borsa, döviz, finans, şirket)
   - "Spor / Magazin" (spor, magazin, ünlüler)
   - "Bilim / Teknoloji" (bilim, teknoloji, yapay zeka, internet)
   - "Kültür / Sanat" (kültür, sanat, müzik, sinema, edebiyat)

ÖNEMLİ KURALLAR:
- EN AZ 150 KELİME yaz. 150 kelimeden AZ yazma. EN FAZLA 300 kelime olmalı.
- Türkçe imla ve yazım kurallarına HARİCİ DİKKAT ET:
  * "kaza" (oluşan olay) vs "kazı" (arkeolojik) — doğru ek kullan (kazada, kazıda)
  * "ile", "için", "gibi" gibi ekler ayrı yazılır
  * "ki" eki çoğu durumda bitişik yazılır (kişi, amaçki → ama bağlaç olan ki ayrı: "bilmem ki")
  * Yabancı dillerden gelen kelimelerde düzeltme işareti (â, î, û) kullan
  * Sayıların yazımı: 150 kelime değil yüz elli kelime gibi
- Cümlelerin kaynaklardaki cümlelerle BİREBİR AYNI OLMAMALIDIR — telif cezası almamak için paraphrase yap.
  * İSTİSNA: Kaynaklarda tırnak içinde verilen doğrudan alıntılar (kişilerin sözleri, açıklamaları) olduğu gibi korunabilir. Örnek: kaynakta "Sinem Dedetaş, 'Deniz Göktaş için iyi çocuktur üzüldüm' dedi" şeklinde geçiyorsa, bu alıntı cümlesi tırnak içinde aynen kullanılabilir. Sadece tırnak dışındaki anlatım paraphrase edilmeli.
- Sadece haberde geçen bilgileri kullan, dış bilgi ekleme, yargılama yapma.
- Haberin tüm önemli detaylarını ver: kim, ne, nerede, ne zaman, nasıl, neden sorularına cevap.
- Haberin arka planı, etkileri ve ilgili kişilerin açıklamalarını da ekle.
- Markdown formatı kullanma, başlık ve liste ekleme — düz metin ver.

Çıktı formatı (her satırı dahil et):
BAŞLIK: <yeni başlığın>
KATEGORİ: <6 kategoriden biri>
ÖZET: <en az 150, en fazla 300 kelimelik özet>

Kaynak metinler:
${blocks.join(`

---

`)}`;
}
var VALID_CATEGORIES = [
  "Güncel",
  "Kamu / Resmi",
  "Ekonomi / Finans",
  "Spor / Magazin",
  "Bilim / Teknoloji",
  "Kültür / Sanat"
];
function normalizeCategory(raw) {
  if (!raw)
    return "Güncel";
  const trimmed = raw.trim();
  for (const c of VALID_CATEGORIES) {
    if (trimmed.toLowerCase() === c.toLowerCase())
      return c;
  }
  const sorted = [...VALID_CATEGORIES].sort((a, b) => b.length - a.length);
  for (const c of sorted) {
    if (trimmed.toLowerCase().includes(c.toLowerCase()))
      return c;
  }
  const lower = trimmed.toLowerCase();
  if (lower.includes("spor") || lower.includes("magazin") || lower.includes("ünlü"))
    return "Spor / Magazin";
  if (lower.includes("kamu") || lower.includes("resmi") || lower.includes("devlet") || lower.includes("memur") || lower.includes("atama"))
    return "Kamu / Resmi";
  if (lower.includes("ekonomi") || lower.includes("finans") || lower.includes("borsa") || lower.includes("döviz") || lower.includes("şirket"))
    return "Ekonomi / Finans";
  if (lower.includes("bilim") || lower.includes("teknoloji") || lower.includes("yapay zeka") || lower.includes("internet"))
    return "Bilim / Teknoloji";
  if (lower.includes("kültür") || lower.includes("sanat") || lower.includes("müzik") || lower.includes("sinema") || lower.includes("edebiyat"))
    return "Kültür / Sanat";
  return "Güncel";
}
function parseAIResponse(text) {
  const titleMatch = text.match(/BAŞLIK:\s*(.+?)(?:\n|$)/i);
  const categoryMatch = text.match(/KATEGORİ:\s*(.+?)(?:\n|$)/i);
  const summaryMatch = text.match(/ÖZET:\s*([\s\S]+?)(?:\n$|$)/i);
  if (!titleMatch || !summaryMatch) {
    const lines = text.trim().split(/\r?\n/);
    if (lines.length >= 2) {
      return { title: lines[0].slice(0, 120), summary: lines.slice(1).join(" ").trim() };
    }
    return null;
  }
  const title = titleMatch[1].trim();
  const summary = summaryMatch[1].trim();
  if (!title || !summary)
    return null;
  const category = categoryMatch ? normalizeCategory(categoryMatch[1]) : "Güncel";
  return { title: title.slice(0, 200), summary, category };
}
function countWords(s) {
  return s.split(/\s+/).filter(Boolean).length;
}
async function summarizeGroup(sources) {
  const sorted = [...sources].sort((a, b) => b.publishedAt.getTime() - a.publishedAt.getTime());
  const chosen = sorted.length > MAX_SOURCES_PER_GROUP ? sorted.slice(0, MAX_SOURCES_PER_GROUP) : sorted;
  if (chosen.length === 0)
    return null;
  const prompt = buildUserPrompt(chosen);
  const MAX_RETRIES = 2;
  const BASE_DELAY_MS = 15000;
  const WORD_COUNT_MIN = 150;
  let lastParsed = null;
  let lastWordCount = 0;
  for (let attempt = 0;attempt < MAX_RETRIES; attempt += 1) {
    try {
      const zai = await getZAI();
      const retryHint = attempt > 0 ? `

ÖNCEKİ YANITIN SADECE ${lastWordCount} KELİME İÇERİYORDU. Bu sefer MUTLAKA EN AZ 150 KELİME yaz.` : "";
      const completion = await zai.chat.completions.create({
        messages: [
          {
            role: "system",
            content: "Sen profesyonel bir Türkçe haber editörüsün. Verilen kaynakları okuyarak telif cezası almayacak şekilde özgün bir haber başlığı, kategori ve özet üretirsin. " + "ÖZET HER ZAMAN EN AZ 150 KELİME, EN FAZLA 300 KELİME OLMALIDIR — bu kurala kesinlikle uy. " + "KATEGORİ satırına 6 kategoriden birini yaz: Güncel, Kamu / Resmi, Ekonomi / Finans, Spor / Magazin, Bilim / Teknoloji, Kültür / Sanat. " + 'TÜRKÇE İMLA KURALLARINA DİKKAT ET: "kaza" (oluşan olay) ile "kazı" (arkeolojik) karıştırmamak, ekleri doğru kullanmak (kazada, kazıda), "ki" bağlacını doğru yazmak. ' + "Kaynak cümlelerini birebir kopyalama; paraphrase yap. ANCAK tırnak içindeki doğrudan alıntıları (kişilerin sözleri) tırnak içinde aynen koru. " + "Haberin tüm önemli detaylarını (kim, ne, ne zaman, nerede, nasıl, neden) ver. " + "Haberin arka planı, etkileri ve ilgili kişilerin açıklamalarını da ekle."
          },
          { role: "user", content: prompt + retryHint }
        ],
        thinking: { type: "disabled" },
        temperature: 0.6
      });
      const text = completion?.choices?.[0]?.message?.content ?? "";
      const parsed = parseAIResponse(text);
      if (!parsed) {
        return { title: "", summary: "", category: "Güncel", error: "AI yanıtı parse edilemedi" };
      }
      lastParsed = parsed;
      lastWordCount = countWords(parsed.summary);
      if (lastWordCount < WORD_COUNT_MIN && attempt < MAX_RETRIES - 1) {
        console.log(`  ⚠️ ${lastWordCount} kelime — kısa (min ${WORD_COUNT_MIN}), retry ${attempt + 2}/${MAX_RETRIES}`);
        await new Promise((r) => setTimeout(r, 3000));
        continue;
      }
      await new Promise((r) => setTimeout(r, BASE_DELAY_MS));
      return parsed;
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      if (msg.includes("429") && attempt < MAX_RETRIES - 1) {
        const waitMs = 30000 * (attempt + 1);
        console.log(`  429 rate limit — ${waitMs / 1000}s bekleniyor (deneme ${attempt + 2}/${MAX_RETRIES})`);
        await new Promise((r) => setTimeout(r, waitMs));
        continue;
      }
      return { title: "", summary: "", category: "Güncel", error: msg };
    }
  }
  if (lastParsed) {
    return lastParsed;
  }
  return { title: "", summary: "", category: "Güncel", error: "Maksimum deneme aşıldı" };
}
async function main() {
  const started = Date.now();
  console.log(`=== RSS Özet Pipeline ===
`);
  if (REBUILD_ONLY) {
    console.log("\uD83D\uDD27 REBUILD_ONLY modu — AI çağrısı yapılmıyor, DB'den dosya üretiliyor");
    const rows = await import_db.db.publishedArticle.findMany({
      where: { status: "published" },
      orderBy: { latestPublishedAt: "desc" }
    });
    console.log(`PublishedArticle: ${rows.length} kayıt`);
    const allArticles = await import_db.db.article.findMany({
      where: { id: { in: rows.flatMap((r) => {
        try {
          return JSON.parse(r.sourceArticleIds);
        } catch {
          return [];
        }
      }) } },
      include: { source: { select: { name: true, url: true } } }
    });
    const articleMap = new Map(allArticles.map((a) => [a.id, a]));
    const published2 = rows.map((r) => {
      let ids = [];
      try {
        ids = JSON.parse(r.sourceArticleIds);
      } catch {}
      const sourceArticleLinks = ids.map((id) => {
        const a = articleMap.get(id);
        return {
          title: a?.title ?? "",
          link: a?.link ?? "",
          source: a?.source.name ?? "",
          publishedAt: a?.publishedAt ?? new Date
        };
      });
      return {
        aiTitle: r.aiTitle,
        aiSummary: r.aiSummary,
        imageUrl: r.imageUrl,
        category: r.category,
        wordCount: r.wordCount,
        sourceArticleIds: ids,
        sourceArticleLinks,
        earliestPublishedAt: r.earliestPublishedAt,
        latestPublishedAt: r.latestPublishedAt,
        sourceCount: r.sourceCount
      };
    });
    await writeRssOzetFile(published2, started);
    return;
  }
  const articles = await import_db.db.article.findMany({
    where: { description: { not: null } },
    include: {
      source: { select: { id: true, name: true, url: true, category: true } }
    },
    orderBy: { publishedAt: "desc" }
  });
  console.log(`Toplam makale: ${articles.length}`);
  const withShingles = articles.map((a) => {
    const norm = normalize(`${a.description ?? ""} ${a.content ?? ""}`);
    const sh1 = shingles(norm, 1);
    const sh2 = shingles(norm, 2);
    return { article: a, sh1, sh2 };
  }).filter((x) => x.sh2.size > 0);
  console.log(`İşlenecek (sh2 > 0): ${withShingles.length}`);
  const inverted = new Map;
  for (let i = 0;i < withShingles.length; i += 1) {
    for (const sh of withShingles[i].sh2) {
      const arr = inverted.get(sh) ?? [];
      arr.push(i);
      inverted.set(sh, arr);
    }
  }
  const candidates = new Set;
  for (const [, idxs] of inverted) {
    if (idxs.length < 2)
      continue;
    for (let i = 0;i < idxs.length; i += 1) {
      for (let j = i + 1;j < idxs.length; j += 1) {
        const a = idxs[i];
        const b = idxs[j];
        if (withShingles[a].article.sourceId === withShingles[b].article.sourceId)
          continue;
        const key = a < b ? `${a},${b}` : `${b},${a}`;
        candidates.add(key);
      }
    }
  }
  console.log(`Aday çift (farklı kaynaklar arası): ${candidates.size}`);
  const uf = new UnionFind(withShingles.length);
  let pairCount = 0;
  for (const key of candidates) {
    const [a, b] = key.split(",").map(Number);
    if (isSimilar(withShingles[a].sh1, withShingles[a].sh2, withShingles[b].sh1, withShingles[b].sh2)) {
      uf.union(a, b);
      pairCount += 1;
    }
  }
  console.log(`Benzer çift (sh2≥%${Math.round(SHINGLE2_THRESHOLD * 100)} VEYA sh1≥%${Math.round(SHINGLE1_THRESHOLD * 100)}): ${pairCount}`);
  const groupsMap = new Map;
  for (let i = 0;i < withShingles.length; i += 1) {
    const root = uf.find(i);
    const arr = groupsMap.get(root) ?? [];
    arr.push(i);
    groupsMap.set(root, arr);
  }
  const duplicateGroups = [];
  for (const group of groupsMap.values()) {
    const uniqueSources = new Set(group.map((i) => withShingles[i].article.sourceId));
    if (uniqueSources.size >= 2)
      duplicateGroups.push(group);
  }
  duplicateGroups.sort((a, b) => {
    const aSources = new Set(a.map((i) => withShingles[i].article.sourceId)).size;
    const bSources = new Set(b.map((i) => withShingles[i].article.sourceId)).size;
    if (aSources !== bSources)
      return bSources - aSources;
    const aMax = Math.max(...a.map((i) => withShingles[i].article.publishedAt.getTime()));
    const bMax = Math.max(...b.map((i) => withShingles[i].article.publishedAt.getTime()));
    return bMax - aMax;
  });
  console.log(`Tekrar eden haber grubu (>= 2 farklı kaynak): ${duplicateGroups.length}
`);
  const groupMetas = duplicateGroups.map((group) => {
    const sourcesInGroup = group.map((i) => withShingles[i].article);
    const bySource = new Map;
    for (const art of sourcesInGroup) {
      const arr = bySource.get(art.sourceId) ?? [];
      arr.push(art);
      bySource.set(art.sourceId, arr);
    }
    const allSources = Array.from(bySource.values()).flat();
    const repSource = allSources[0]?.source;
    const category = repSource?.category ?? "Güncel";
    const latestPublishedAt = new Date(Math.max(...allSources.map((a) => a.publishedAt.getTime())));
    const earliestPublishedAt = new Date(Math.min(...allSources.map((a) => a.publishedAt.getTime())));
    return {
      group,
      sourcesInGroup,
      bySource,
      allSources,
      category,
      latestPublishedAt,
      earliestPublishedAt,
      sourceCount: bySource.size
    };
  });
  const byCategoryMap = new Map;
  for (const gm of groupMetas) {
    const arr = byCategoryMap.get(gm.category) ?? [];
    arr.push(gm);
    byCategoryMap.set(gm.category, arr);
  }
  for (const arr of byCategoryMap.values()) {
    arr.sort((a, b) => b.latestPublishedAt.getTime() - a.latestPublishedAt.getTime());
  }
  const selectedGroups = [];
  for (const cat of CATEGORY_ORDER) {
    const arr = byCategoryMap.get(cat) ?? [];
    const limit = CATEGORY_LIMITS[cat];
    const selected = arr.slice(0, limit);
    selectedGroups.push(...selected);
    console.log(`  ${cat}: ${selected.length}/${arr.length} seçildi (limit ${limit})`);
  }
  console.log(`Toplam AI özetlenecek: ${selectedGroups.length}
`);
  const existingHashes = new Set;
  const existingTitles = [];
  const usedImageUrls = new Set;
  const existing = await import_db.db.publishedArticle.findMany({
    where: { status: { in: ["draft", "published", "stale"] } },
    select: {
      sourceArticleIds: true,
      status: true,
      id: true,
      aiTitle: true,
      aiSummary: true,
      imageUrl: true
    }
  });
  for (const d of existing) {
    existingHashes.add(d.sourceArticleIds);
    if (d.aiTitle) {
      const norm = normalize(d.aiTitle);
      existingTitles.push({
        title: d.aiTitle,
        sh1: shingles(norm, 1),
        sh2: shingles(norm, 2)
      });
    }
    if (d.imageUrl)
      usedImageUrls.add(d.imageUrl);
  }
  console.log(`Mevcut özet (draft+published+stale): ${existingHashes.size} (atlanacak/restore edilecek)`);
  console.log(`Mevcut başlık sayısı (benzerlik kontrolü için): ${existingTitles.length}`);
  console.log(`Mevcut görsel sayısı (görsel dedup için): ${usedImageUrls.size}`);
  function findSimilarExisting(title) {
    const norm = normalize(title);
    const sh1 = shingles(norm, 1);
    const sh2 = shingles(norm, 2);
    for (const e of existingTitles) {
      if (isSimilar(sh1, sh2, e.sh1, e.sh2)) {
        return { title: e.title, sh1: e.sh1, sh2: e.sh2 };
      }
    }
    return null;
  }
  const published = [];
  let successCount = 0;
  let errorCount = 0;
  let skippedCount = 0;
  let restoredCount = 0;
  let autoPublishedBatches = 0;
  let draftCounter = 0;
  async function autoPublishDrafts() {
    const r = await import_db.db.publishedArticle.updateMany({
      where: { status: "draft" },
      data: { status: "published", publishedAt: new Date }
    });
    if (r.count > 0) {
      autoPublishedBatches += 1;
      console.log(`  \uD83D\uDCE4 Auto-publish (batch ${autoPublishedBatches}): ${r.count} haber yayınlandı`);
    }
    return r.count;
  }
  for (let gi = 0;gi < selectedGroups.length; gi += 1) {
    const gm = selectedGroups[gi];
    const sortedIds = [...gm.allSources.map((a) => a.id)].sort();
    const hash = JSON.stringify(sortedIds);
    if (existingHashes.has(hash)) {
      const existingRow = await import_db.db.publishedArticle.findFirst({
        where: { sourceArticleIds: hash, status: { in: ["draft", "published", "stale"] } }
      });
      if (existingRow) {
        if (existingRow.status === "stale") {
          await import_db.db.publishedArticle.update({
            where: { id: existingRow.id },
            data: { status: "published", publishedAt: new Date }
          });
          restoredCount += 1;
          console.log(`[${gi + 1}/${selectedGroups.length}] \uD83D\uDD04 Restore (stale → published): ${existingRow.aiTitle.slice(0, 50)}`);
        } else {
          skippedCount += 1;
          console.log(`[${gi + 1}/${selectedGroups.length}] ⏭️ Atlandı (zaten ${existingRow.status})`);
        }
        published.push({
          aiTitle: existingRow.aiTitle,
          aiSummary: existingRow.aiSummary,
          imageUrl: existingRow.imageUrl,
          category: existingRow.category,
          wordCount: existingRow.wordCount,
          sourceArticleIds: sortedIds,
          sourceArticleLinks: gm.allSources.map((a) => ({
            title: a.title,
            link: a.link,
            source: a.source.name,
            publishedAt: a.publishedAt
          })),
          earliestPublishedAt: gm.earliestPublishedAt,
          latestPublishedAt: gm.latestPublishedAt,
          sourceCount: gm.sourceCount
        });
      }
      continue;
    }
    const result = await summarizeGroup(gm.allSources);
    if (!result || result.error || !result.title || !result.summary) {
      errorCount += 1;
      console.log(`[${gi + 1}/${selectedGroups.length}] ⚠️ Atlandı: ${result?.error ?? "boş yanıt"}`);
      continue;
    }
    const similar = findSimilarExisting(result.title);
    if (similar) {
      skippedCount += 1;
      console.log(`[${gi + 1}/${selectedGroups.length}] ⏭️ Benzer başlık atlandı: "${result.title.slice(0, 50)}" ≈ "${similar.title.slice(0, 50)}"`);
      continue;
    }
    const wordCount = countWords(result.summary);
    if (wordCount < MIN_SUMMARY_WORDS - 30) {
      console.log(`[${gi + 1}/${selectedGroups.length}] ⚠️ Kısa özet (${wordCount} kelime) — yine de kaydedildi`);
    }
    const imageUrl = pickImage(gm.allSources, usedImageUrls);
    if (imageUrl) {
      usedImageUrls.add(imageUrl);
    } else {
      console.log(`[${gi + 1}/${selectedGroups.length}] \uD83D\uDDBC️ Görsel benzersiz seçilemedi (tüm alternatifler kullanımda) — görselsiz yayınlanacak`);
    }
    const newNorm = normalize(result.title);
    existingTitles.push({
      title: result.title,
      sh1: shingles(newNorm, 1),
      sh2: shingles(newNorm, 2)
    });
    const sourceArticleLinks = gm.allSources.map((a) => ({
      title: a.title,
      link: a.link,
      source: a.source.name,
      publishedAt: a.publishedAt
    }));
    const aiCategory = result.category ?? gm.category;
    try {
      await import_db.db.publishedArticle.create({
        data: {
          aiTitle: result.title,
          aiSummary: result.summary,
          imageUrl,
          category: aiCategory,
          wordCount,
          sourceArticleIds: hash,
          sourceCount: gm.sourceCount,
          earliestPublishedAt: gm.earliestPublishedAt,
          latestPublishedAt: gm.latestPublishedAt,
          status: "draft"
        }
      });
      draftCounter += 1;
    } catch (e) {
      console.log(`[${gi + 1}/${selectedGroups.length}] DB yazma hatası: ${e instanceof Error ? e.message : String(e)}`);
    }
    published.push({
      aiTitle: result.title,
      aiSummary: result.summary,
      imageUrl,
      category: aiCategory,
      wordCount,
      sourceArticleIds: sortedIds,
      sourceArticleLinks,
      earliestPublishedAt: gm.earliestPublishedAt,
      latestPublishedAt: gm.latestPublishedAt,
      sourceCount: gm.sourceCount
    });
    successCount += 1;
    console.log(`[${gi + 1}/${selectedGroups.length}] ✓ "${result.title.slice(0, 60)}" — ${wordCount} kelime, ${gm.sourceCount} kaynak, ${aiCategory}`);
    if (draftCounter >= 3) {
      await autoPublishDrafts();
      draftCounter = 0;
    }
  }
  if (draftCounter > 0) {
    await autoPublishDrafts();
  }
  console.log(`
Özetleme tamam: ${successCount} yeni AI özet, ${restoredCount} stale→published, ${skippedCount} atlandı, ${errorCount} hata, ${autoPublishedBatches} publish batch, ${((Date.now() - started) / 1000).toFixed(1)}s`);
  const finalSelection = published;
  for (const p of finalSelection) {
    if (!existingHashes.has(JSON.stringify(p.sourceArticleIds))) {}
  }
  await writeRssOzetFile(finalSelection, started);
}
async function writeRssOzetFile(finalSelection, started) {
  const lines = [];
  lines.push("# RSS Özet — Yeniden Yazılmış Haber Özetleri");
  lines.push("");
  lines.push("Birden fazla kaynakta çıkan haberler için AI tarafından telif güvenli (paraphrase) şekilde yeniden yazılmış başlık ve özetler.");
  lines.push("");
  lines.push(`- **Oluşturulma:** ${import_date_fns.format(new Date, "d MMM yyyy HH:mm", { locale: import_locale.tr })}`);
  lines.push(`- **Toplam özetlenen haber:** ${finalSelection.length}`);
  lines.push(`- **Kategori limitleri:** Güncel 10, Kamu 7, Ekonomi 7, Spor 5, Bilim 3, Kültür 3`);
  lines.push(`- **Kelime hedefi:** en az 100 kelime`);
  lines.push("");
  lines.push("---");
  lines.push("");
  for (const cat of CATEGORY_ORDER) {
    const items = finalSelection.filter((p) => p.category === cat);
    lines.push(`## ${cat} (${items.length} haber)`);
    lines.push("");
    for (const p of items) {
      lines.push(`### ${p.aiTitle}`);
      lines.push("");
      lines.push(`- **Yayın aralığı:** ${fmtDate(p.earliestPublishedAt)} – ${fmtDate(p.latestPublishedAt)}`);
      lines.push(`- **Farklı kaynak sayısı:** ${p.sourceCount}`);
      lines.push(`- **Kelime sayısı:** ${p.wordCount}`);
      if (p.imageUrl) {
        lines.push(`- **Görsel:** ${p.imageUrl}`);
      }
      lines.push("");
      lines.push(`**Özet:**`);
      lines.push("");
      lines.push(p.aiSummary);
      lines.push("");
      lines.push("**Kaynaklar:**");
      lines.push("");
      for (let i = 0;i < p.sourceArticleLinks.length; i += 1) {
        const s = p.sourceArticleLinks[i];
        lines.push(`${i + 1}. [${s.title}](${s.link}) — ${s.source} — ${fmtDate(s.publishedAt)}`);
      }
      lines.push("");
      lines.push("---");
      lines.push("");
    }
  }
  lines.push("## Üretim Bilgisi");
  lines.push("");
  lines.push(`- **Oluşturan:** build-rss-ozet.ts`);
  lines.push(`- **Tarih:** ${new Date().toISOString()}`);
  lines.push(`- **Algoritma:** HİBRİT — 2-gram shingle Jaccard ≥ %${Math.round(SHINGLE2_THRESHOLD * 100)} VEYA 1-gram (kelime kümesi) Jaccard ≥ %${Math.round(SHINGLE1_THRESHOLD * 100)} + Union-Find + z-ai-web-dev-sdk paraphrase`);
  lines.push(`- **Çalışma süresi:** ${((Date.now() - started) / 1000).toFixed(1)} saniye`);
  lines.push("");
  import_node_fs.mkdirSync(import_node_path.default.dirname(OUTPUT_PATH), { recursive: true });
  import_node_fs.writeFileSync(OUTPUT_PATH, lines.join(`
`), "utf-8");
  const sizeKb = Math.round(lines.join(`
`).length / 1024 * 10) / 10;
  console.log(`
Dosya yazıldı: ${OUTPUT_PATH} (${sizeKb} KB, ${lines.length} satır)`);
}
main().catch((e) => {
  console.error("Pipeline hatası:", e);
  process.exit(1);
}).finally(async () => {
  await import_db.db.$disconnect();
});
