var __create = Object.create;
var __getProtoOf = Object.getPrototypeOf;
var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
function __accessProp(key) {
  return this[key];
}
var __toESMCache_node;
var __toESMCache_esm;
var __toESM = (mod, isNodeMode, target) => {
  var canCache = mod != null && typeof mod === "object";
  if (canCache) {
    var cache = isNodeMode ? __toESMCache_node ??= new WeakMap : __toESMCache_esm ??= new WeakMap;
    var cached = cache.get(mod);
    if (cached)
      return cached;
  }
  target = mod != null ? __create(__getProtoOf(mod)) : {};
  const to = isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target;
  for (let key of __getOwnPropNames(mod))
    if (!__hasOwnProp.call(to, key))
      __defProp(to, key, {
        get: __accessProp.bind(mod, key),
        enumerable: true
      });
  if (canCache)
    cache.set(mod, to);
  return to;
};

// scripts/build-rss-icerik.ts
var import_db = require("../src/lib/db");
var import_node_fs = require("node:fs");
var import_node_path = __toESM(require("node:path"));
var import_date_fns = require("date-fns");
var import_locale = require("date-fns/locale");
var OUTPUT_PATH = import_node_path.default.join(process.cwd(), "download", "rss_icerik.md");
var CATEGORIES = [
  "Güncel",
  "Kamu / Resmi",
  "Ekonomi / Finans",
  "Bilim / Teknoloji",
  "Spor / Magazin",
  "Kültür / Sanat"
];
function escapeMd(s) {
  if (!s)
    return "";
  return s.replace(/\[/g, "\\[").replace(/\]/g, "\\]").replace(/\r?\n/g, " ").trim();
}
function fmtDate(d) {
  if (!d)
    return "";
  const date = typeof d === "string" ? new Date(d) : d;
  if (Number.isNaN(date.getTime()))
    return "";
  return import_date_fns.format(date, "d MMM yyyy HH:mm", { locale: import_locale.tr });
}
async function main() {
  console.log("=== RSS İçerik Dosyası Oluşturma ===");
  const totalArticles = await import_db.db.article.count();
  const totalSources = await import_db.db.source.count();
  const withDescription = await import_db.db.article.count({
    where: { description: { not: null } }
  });
  console.log(`Makale: ${totalArticles}, Kaynak: ${totalSources}, Açıklamalı: ${withDescription}`);
  const lines = [];
  lines.push("# RSS İçerik Derlemesi");
  lines.push("");
  lines.push("RSS kaynaklarından alınan haber derlemesi. Her haberin orijinal kısa açıklaması ve kaynak linki yer alır.");
  lines.push("");
  lines.push(`- **Oluşturulma:** ${import_date_fns.format(new Date, "d MMM yyyy HH:mm", { locale: import_locale.tr })}`);
  lines.push(`- **Toplam makale:** ${totalArticles}`);
  lines.push(`- **Toplam kaynak:** ${totalSources} (6 kategori)`);
  lines.push(`- **Açıklamalı makale:** ${withDescription}`);
  lines.push("");
  lines.push("---");
  lines.push("");
  for (const category of CATEGORIES) {
    const articles = await import_db.db.article.findMany({
      where: {
        OR: [{ category }, { source: { category } }]
      },
      orderBy: { publishedAt: "desc" },
      include: { source: { select: { name: true, url: true } } }
    });
    lines.push(`## ${category} (${articles.length} makale)`);
    lines.push("");
    if (articles.length === 0) {
      lines.push("_Bu kategoride henüz makale yok._");
      lines.push("");
      lines.push("---");
      lines.push("");
      continue;
    }
    const bySource = new Map;
    for (const a of articles) {
      const sName = a.source?.name ?? "Bilinmiyor";
      const sUrl = a.source?.url ?? "";
      if (!bySource.has(sName)) {
        bySource.set(sName, { name: sName, url: sUrl, articles: [] });
      }
      bySource.get(sName).articles.push(a);
    }
    for (const [, info] of Array.from(bySource.entries())) {
      lines.push(`### Kaynak: [${info.name}](${info.url})`);
      lines.push("");
      lines.push(`_${info.articles.length} makale_`);
      lines.push("");
      for (const a of info.articles) {
        const title = escapeMd(a.title) || "(Başlıksız)";
        const link = a.link || a.source?.url || "";
        lines.push(`#### [${title}](${link})`);
        lines.push("");
        lines.push(`- **Yayın:** ${fmtDate(a.publishedAt)}`);
        lines.push(`- **Kategori:** ${escapeMd(category)}`);
        lines.push(`- **Kaynak linki:** ${link}`);
        lines.push("");
        if (a.description) {
          const desc = a.description.slice(0, 600);
          const suffix = a.description.length > 600 ? "…" : "";
          lines.push(`_${desc}${suffix}_`);
          lines.push("");
        } else {
          lines.push("_(RSS açıklaması yok)_");
          lines.push("");
        }
        lines.push("---");
        lines.push("");
      }
    }
  }
  lines.push("## Üretim Bilgisi");
  lines.push("");
  lines.push(`- **Oluşturan:** Haber Özet build-rss-icerik.ts`);
  lines.push(`- **Tarih:** ${new Date().toISOString()}`);
  lines.push(`- **Toplam satır:** ${lines.length}`);
  lines.push("");
  import_node_fs.mkdirSync(import_node_path.default.dirname(OUTPUT_PATH), { recursive: true });
  import_node_fs.writeFileSync(OUTPUT_PATH, lines.join(`
`), "utf-8");
  const sizeKb = Math.round(lines.join(`
`).length / 1024 * 10) / 10;
  console.log(`
Dosya yazıldı: ${OUTPUT_PATH} (${sizeKb} KB, ${lines.length} satır)`);
}
main().catch((e) => {
  console.error("Build hatası:", e);
  process.exit(1);
}).finally(async () => {
  await import_db.db.$disconnect();
});
