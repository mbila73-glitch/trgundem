// scripts/trigger-refresh.ts
var import_rss = require("../src/lib/rss");
var import_db = require("../src/lib/db");
async function main() {
  console.log("=== Arka plan RSS yenilemesi başlatıldı ===");
  const started = Date.now();
  const results = await import_rss.refreshAllActiveSources();
  const duration = Math.round((Date.now() - started) / 1000);
  const totalAdded = results.reduce((a, r) => a + r.added, 0);
  const totalFetched = results.reduce((a, r) => a + r.fetched, 0);
  const failed = results.filter((r) => r.error);
  console.log(`
=== Yenileme tamam (${duration}s) ===`);
  console.log(`İşlenen kaynak: ${results.length}`);
  console.log(`Çekilen öğe:    ${totalFetched}`);
  console.log(`Eklenen makale: ${totalAdded}`);
  console.log(`Başarısız kaynak: ${failed.length}`);
  if (failed.length > 0) {
    console.log(`
İlk 15 hata:`);
    failed.slice(0, 15).forEach((r) => {
      console.log(`  · ${r.sourceName}: ${r.error?.slice(0, 80)}`);
    });
  }
  const totalArticles = await import_db.db.article.count();
  const totalSources = await import_db.db.source.count();
  console.log(`
DB durumu: ${totalSources} kaynak, ${totalArticles} makale.`);
}
main().catch((e) => {
  console.error("Yenileme hatası:", e);
  process.exit(1);
}).finally(async () => {
  await import_db.db.$disconnect();
});
